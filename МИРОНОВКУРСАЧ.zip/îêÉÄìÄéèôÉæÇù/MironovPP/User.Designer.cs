﻿namespace MironovPP
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.AddLechenie = new System.Windows.Forms.Button();
            this.GoToMedCarta = new System.Windows.Forms.Button();
            this.PriemGo = new System.Windows.Forms.Button();
            this.RegPatient = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.AddLechenie);
            this.panel1.Controls.Add(this.GoToMedCarta);
            this.panel1.Controls.Add(this.PriemGo);
            this.panel1.Controls.Add(this.RegPatient);
            this.panel1.Controls.Add(this.Close);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(690, 303);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(214, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(216, 50);
            this.panel2.TabIndex = 75;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(17, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 25);
            this.label1.TabIndex = 29;
            this.label1.Text = "Главная форма";
            // 
            // AddLechenie
            // 
            this.AddLechenie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.AddLechenie.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddLechenie.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.AddLechenie.FlatAppearance.BorderSize = 0;
            this.AddLechenie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddLechenie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddLechenie.ForeColor = System.Drawing.Color.White;
            this.AddLechenie.Location = new System.Drawing.Point(214, 246);
            this.AddLechenie.Margin = new System.Windows.Forms.Padding(4);
            this.AddLechenie.Name = "AddLechenie";
            this.AddLechenie.Size = new System.Drawing.Size(216, 35);
            this.AddLechenie.TabIndex = 72;
            this.AddLechenie.Text = "Назначение лечения";
            this.AddLechenie.UseVisualStyleBackColor = false;
            this.AddLechenie.Click += new System.EventHandler(this.AddLechenie_Click);
            // 
            // GoToMedCarta
            // 
            this.GoToMedCarta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.GoToMedCarta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GoToMedCarta.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.GoToMedCarta.FlatAppearance.BorderSize = 0;
            this.GoToMedCarta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GoToMedCarta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoToMedCarta.ForeColor = System.Drawing.Color.White;
            this.GoToMedCarta.Location = new System.Drawing.Point(214, 188);
            this.GoToMedCarta.Margin = new System.Windows.Forms.Padding(4);
            this.GoToMedCarta.Name = "GoToMedCarta";
            this.GoToMedCarta.Size = new System.Drawing.Size(216, 35);
            this.GoToMedCarta.TabIndex = 71;
            this.GoToMedCarta.Text = "Медицинская карта";
            this.GoToMedCarta.UseVisualStyleBackColor = false;
            this.GoToMedCarta.Click += new System.EventHandler(this.GoToMedCarta_Click);
            // 
            // PriemGo
            // 
            this.PriemGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PriemGo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PriemGo.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.PriemGo.FlatAppearance.BorderSize = 0;
            this.PriemGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PriemGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriemGo.ForeColor = System.Drawing.Color.White;
            this.PriemGo.Location = new System.Drawing.Point(214, 131);
            this.PriemGo.Margin = new System.Windows.Forms.Padding(4);
            this.PriemGo.Name = "PriemGo";
            this.PriemGo.Size = new System.Drawing.Size(216, 35);
            this.PriemGo.TabIndex = 70;
            this.PriemGo.Text = "Приёмы";
            this.PriemGo.UseVisualStyleBackColor = false;
            this.PriemGo.Click += new System.EventHandler(this.PriemGo_Click);
            // 
            // RegPatient
            // 
            this.RegPatient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.RegPatient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RegPatient.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.RegPatient.FlatAppearance.BorderSize = 0;
            this.RegPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RegPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegPatient.ForeColor = System.Drawing.Color.White;
            this.RegPatient.Location = new System.Drawing.Point(214, 70);
            this.RegPatient.Margin = new System.Windows.Forms.Padding(4);
            this.RegPatient.Name = "RegPatient";
            this.RegPatient.Size = new System.Drawing.Size(216, 35);
            this.RegPatient.TabIndex = 69;
            this.RegPatient.Text = "Регистрация пациентов";
            this.RegPatient.UseVisualStyleBackColor = false;
            this.RegPatient.Click += new System.EventHandler(this.RegPatient_Click);
            // 
            // Close
            // 
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Close.Location = new System.Drawing.Point(652, 3);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(33, 25);
            this.Close.TabIndex = 67;
            this.Close.Text = "X";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click_1);
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 330);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "User";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button AddLechenie;
        private System.Windows.Forms.Button GoToMedCarta;
        private System.Windows.Forms.Button PriemGo;
        private System.Windows.Forms.Button RegPatient;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
    }
}