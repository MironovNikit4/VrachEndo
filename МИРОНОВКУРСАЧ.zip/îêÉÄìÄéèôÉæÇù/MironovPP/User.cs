﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }
        private void Close_Click_1(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void RegPatient_Click(object sender, EventArgs e)
        {
            RegistrationPatient registrationPatient = new RegistrationPatient();
            registrationPatient.Show();
            this.Hide();
        }

        private void PriemGo_Click(object sender, EventArgs e)
        {
            Priem priem = new Priem();
            priem.Show();
            this.Hide();
        }

        private void GoToMedCarta_Click(object sender, EventArgs e)
        {
            MedCard medCard = new MedCard();
            medCard.Show();
            this.Hide();
        }

        private void AddLechenie_Click(object sender, EventArgs e)
        {
            Lechenie lechenie = new Lechenie();
            lechenie.Show();
            this.Hide();
        }
    }
}
