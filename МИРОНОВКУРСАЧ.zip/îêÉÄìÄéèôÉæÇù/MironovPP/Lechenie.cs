﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class Lechenie : Form
    {
         private string connectionString = "Data Source=DESKTOP-CTEHH5B\\SQLEXPRESS;Initial Catalog=Vrach;Integrated Security=True;Encrypt=False";
        public Lechenie()
        {
            InitializeComponent();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Show();
            this.Close();
        }

        private void AddLechenie_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Лечение успешно назначено.");
        }
    }
}
