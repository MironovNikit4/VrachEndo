﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MironovPP
{
    public partial class MedCard : Form
    {

        string connectionString = @"Data Source=DESKTOP-CTEHH5B\SQLEXPRESS;Initial Catalog=Vrach;Integrated Security=True;Encrypt=False";
        public MedCard()
        {
            InitializeComponent();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            Priem specialist = new Priem();
            specialist.Show();
            this.Close();
        }

        private void SaveCard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Запись успешно занесена в медкарту.");
        }

        private void CheckPatient_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Patient";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        // Открываем подключение и создаем адаптер данных
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();

                        // Заполняем таблицу данными из базы данных
                        adapter.Fill(dataTable);

                        // Привязываем таблицу к элементу управления DataGridView
                        dataGridViewCards.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
                    }
                }
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Show();
            this.Close();
        }
    }
}
